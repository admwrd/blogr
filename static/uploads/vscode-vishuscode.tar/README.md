# README
## Vishus Code
This is the VS Code version of my Vishus Code theme for Sublime Text.

You are free to use and modify it as you wish, however you may not modify or remove the copyright information.

Enjoy.
